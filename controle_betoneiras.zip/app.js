
const listaBetoneirasEl = document.getElementById('listaBetoneiras');
const historicoEl = document.getElementById('historico');
const alertaEscassezEl = document.getElementById('alertaEscassez');
const formAdd = document.getElementById('formAdd');
const searchInput = document.getElementById('searchInput');
const statusFilter = document.getElementById('statusFilter');

let betoneiras = [];
let historico = [];

function inicializarBetoneiras() {
  betoneiras = [];
  for (let i = 1; i <= 120; i++) {
    const id = 'bt' + i.toString().padStart(2, '0');
    betoneiras.push({
      id,
      nome: `${id} betoneira 400L`,
      status: 'Disponível',
      usuario: ''
    });
  }
  salvarBetoneiras();
}

function salvarBetoneiras() {
  localStorage.setItem('betoneiras', JSON.stringify(betoneiras));
}

function carregarBetoneiras() {
  const dados = localStorage.getItem('betoneiras');
  if (dados) {
    betoneiras = JSON.parse(dados);
  } else {
    inicializarBetoneiras();
  }
}

function salvarHistorico() {
  localStorage.setItem('historico', JSON.stringify(historico));
}

function carregarHistorico() {
  const dados = localStorage.getItem('historico');
  if (dados) {
    historico = JSON.parse(dados);
  }
}

function adicionarHistorico(texto) {
  const data = new Date().toLocaleString();
  historico.unshift(`${data} - ${texto}`);
  if (historico.length > 50) historico.pop();
  salvarHistorico();
  atualizarHistorico();
}

function atualizarHistorico() {
  historicoEl.innerHTML = '';
  for (const item of historico) {
    const li = document.createElement('li');
    li.textContent = item;
    historicoEl.appendChild(li);
  }
}

function atualizarLista() {
  listaBetoneirasEl.innerHTML = '';
  const filtroStatus = statusFilter.value;
  const termoBusca = searchInput.value.trim().toLowerCase();
  let countDisponivel = 0;

  for (const betoneira of betoneiras) {
    if (filtroStatus && betoneira.status !== filtroStatus) continue;

    const buscaConcat = (betoneira.id + ' ' + betoneira.nome).toLowerCase();
    if (termoBusca && !buscaConcat.includes(termoBusca)) continue;

    const li = document.createElement('li');

    const texto = document.createElement('span');
    texto.textContent = `${betoneira.nome} - Usuário: ${betoneira.usuario || '-'}`;

    const statusSpan = document.createElement('span');
    statusSpan.textContent = betoneira.status;
    statusSpan.className = 'status ' + betoneira.status;

    li.appendChild(texto);
    li.appendChild(statusSpan);

    listaBetoneirasEl.appendChild(li);

    if (betoneira.status === 'Disponível') countDisponivel++;
  }

  if (countDisponivel < 10) {
    alertaEscassezEl.textContent = `⚠️ Atenção! Restam apenas ${countDisponivel} betoneiras disponíveis.`;
  } else {
    alertaEscassezEl.textContent = '';
  }
}

function exportCSV() {
  let csv = 'ID,Nome,Status,Usuário\n';
  for (const b of betoneiras) {
    csv += `${b.id},"${b.nome}",${b.status},"${b.usuario}"\n`;
  }
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'betoneiras.csv';
  a.click();
  URL.revokeObjectURL(url);
}

function exportBackup() {
  const data = {
    betoneiras,
    historico
  };
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'backup-betoneiras.json';
  a.click();
  URL.revokeObjectURL(url);
}

formAdd.addEventListener('submit', e => {
  e.preventDefault();

  const idRaw = document.getElementById('betoneiraId').value.trim().toLowerCase();
  const id = idRaw.startsWith('bt') ? idRaw : 'bt' + idRaw.padStart(2, '0');
  const status = document.getElementById('betoneiraStatus').value;
  const usuario = document.getElementById('usuario').value.trim();

  const existe = betoneiras.find(b => b.id === id);
  if (!existe) {
    alert('ID inválido! Deve estar entre bt01 e bt120');
    return;
  }

  existe.status = status;
  existe.usuario = usuario;

  adicionarHistorico(`Betoneira ${existe.id} atualizada para status "${status}" pelo usuário "${usuario}"`);

  salvarBetoneiras();
  atualizarLista();

  formAdd.reset();
});

function filterByStatus() {
  atualizarLista();
}

function filterBySearch() {
  atualizarLista();
}

carregarBetoneiras();
carregarHistorico();
atualizarLista();
atualizarHistorico();
